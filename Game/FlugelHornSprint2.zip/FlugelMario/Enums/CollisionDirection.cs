﻿namespace SuperMario.Enums
{
    public enum CollisionDirection
    {
        Top,
        Bottom,
        Left,
        Right
    }
}
