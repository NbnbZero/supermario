using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperMario.Interfaces
{
    interface ICommand
    {
        void Execute(InputState state, IMarioState marioState);

        void Execute();
    }
}
