Author Haifeng Yang

-I did not show the animation of fireball in the game.

-Instead of Gamepad controller setting for the pause game
I did the keyboard control for test convinence.
